import React from "react";


class Users extends React.Component{
    
    render(){
        <div className="user">
            <h1>Gestión de Usuarios</h1>
            <form>
                <lbel></lbel>
            </form>

        </div>

    }
}